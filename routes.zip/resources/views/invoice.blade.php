<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hello</title>


    <style>

        @font-face {
            font-family: 'solaimanlipi';
            src: url({{ storage_path('fonts/SolaimanLipi_20-04-07.ttf') }}) format("truetype");
        }

        body, h4,p {
            font-family: "solaimanlipi";
        }

    </style>

</head>
<body>


<h4>হ্যালো ওয়ার্ল্ড  </h4>
<p>Hello</p>


</body>
</html>
