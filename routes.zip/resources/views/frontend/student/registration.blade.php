@extends("layouts.common")
@section("content")

<section>
  <div class="registration-home"></div>
</section>
    
    <section class="form-area">
    
        <div class="container">

            <div class="row">
                <div class="reg-main-page">
                <div class="ps">
                <button class="student-btn"><a  href="/current-student/personal-info">বর্তমান শিক্ষার্থী</a></button>
                    
                </div>
                <div style="padding-top:30px;" class="mt-2 ps">
                <button class="student-btn"><a href="/student/personal-info">প্রাক্তন শিক্ষার্থী </a></button>
                </div>
                </div>
                



            </div>
        </div>
    </section>

@endsection
