@extends("layouts.common")
@section("content")


<section>

<div class="container">
  <div class="raw">
  <div class="col-lg-12">
                    <div style="background:#198754;" class="breadcrumb-content text-center">
                        <div class="section-heading">
                            <h2 style="color:#FFF; padding:15px 15px" class="section__title">Refund Policy</h2>
                        </div>
                    </div><!-- end breadcrumb-content -->
                </div>
  </div>
            <div class="row">
                <h4> Refund Policy</h4>

            </div><!-- end row -->

            <div style="padding:150px 150px"  class="row">
                <p> Once a ticket has been purchased, it will not be returned.</p>
            </div>

        </div>
    </section>


@endsection